import React , {useEffect} from "react";
import "./Cal.css"; 
// import "bootstrap/dist/css/bootstrap.min.css";
import card1 from "../../Assests/Images/Avatar 1.png";
import card2 from "../../Assests/Images/Avatar 2.png";
import card3 from "../../Assests/Images/Avatar 3.png";
import card4 from "../../Assests/Images/Base.png";
import card5 from "../../Assests/Images/Avatar Image.png";
import card6 from "../../Assests/Images/Avatar 7.png";
import card7 from "../../Assests/Images/Avatar Image (1).png";
import card8 from "../../Assests/Images/Avatar 10.png";
import date from "../../Assests/Images/Input Field (1).png";

import card9 from "../../Assests/Images/Avatar Image (2).png";
import cards1 from "../../Assests/Images/Avatar 13.png";

import carts2 from "../../Assests/Images/Avatar Image (6).png";
import carts3 from "../../Assests/Images/Avatar Image (7).png";

import carts4 from "../../Assests/Images/Avatar Image (7).png";
import carts5 from "../../Assests/Images/Avatar 15.png";

import carts6 from "../../Assests/Images/Avatar Image (9).png";
import carts7 from "../../Assests/Images/Avatar 6.png";

import carts8 from "../../Assests/Images/Avatar Image (10).png";
import carts9 from "../../Assests/Images/Avatar Image (11).png";


const Calendar = () => {


  useEffect(() => {
    
    document.querySelectorAll('td').forEach(td => {
      td.classList.add('thd');
     });
    }, []);

  
  return (
    <div className="m-4">
      <div className="bg-white p-3 gap-0">
        <div className="d-flex justify-content-between align-items-center mt-4 mb-3  ">
          <h5 style={{ marginLeft: "20px" }}>Calendar</h5>
          <img src={date} style={{ marginRight: "14px" }} alt="Date Icon" />
        </div>

        <table className="table rounded-3">
          <thead>
           
          
          </thead>
          <tbody>

           <tr>
           <td colSpan={8}>
  <div class="container mt-4">
    <div class="row align-items-center">
      <div class="col-md-4">
        <button type="button" class="btn btn-primary">Today</button>
      </div>
      <div class="col-md-4 d-flex justify-content-center">
        <span class="h5">May 12, 2024</span>
      </div>
      <div class="col-md-4 d-flex justify-content-end">
        <div class="btn-group" role="group">
          <button type="button" class="btn btn-outline-primary">Day</button>
          <button type="button" class="btn btn-outline-primary">Week</button>
          <button type="button" class="btn btn-outline-primary">Month</button>
          <button type="button" class="btn btn-outline-primary">Year</button>
        </div>
      </div>
    </div>
  </div>
</td>




           </tr>
          <tr className="rowed" style={{ textAlign: "center" }}>
            
              <th className="rowed" style={{ height: "67px", width: "62px" }}>
                <span className="bi bi-clock"></span>
              </th>
              <th className="rowed">Monday 12</th>
              <th className="rowed">Tuesday 13</th>
              <th className="rowed">Wednesday 14</th>
              <th className="rowed">Thursday 15</th>
              <th className="rowed">Friday 16</th>
              <th className="rowed">Saturday 17</th>
              <th className="rowed">Sunday 18</th>
            </tr>
            <tr>
              <td
                style={{
                  height: "67px",
                  width: "62px",
                  textAlign: "center",
                  verticalAlign: "middle",
                }}
              >
                09
              </td>
              <td rowSpan="2" className="event">
                <div className="d-flex flex-column justify-content-around cart  align-items-start  p-2  ">
                  <div className="d-flex flex-column">
                    <div className="d-flex gap-1">
                      <span className="star ">09.00</span>
                      <span className="star">10:59</span>
                    </div>
                    <p className="heading">shooting stars</p>
                  </div>
                  <div>
                    <img
                      src={card1}
                      width="26px"
                      height="26px"
                      className="me-2"
                    ></img>
                    <img src={card2} width="26px" height="26px"></img>
                  </div>
                </div>
              </td>{" "}
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
            </tr>

            <tr>
              <td
                style={{
                  height: "67px",
                  width: "62px",
                  textAlign: "center",
                  verticalAlign: "middle",
                }}
              >
                10
              </td>
              <td></td>
              <td></td>

              <td rowSpan="2">
                <div
                  className="d-flex flex-column justify-content-around cart  align-items-start  p-2   "
                  style={{
                    border: "2px solid #FF6633",
                    backgroundColor: "rgba(255,102,51,0.05)",
                    width:"150px"
                  }}
                >
                  <div className="gap-5 text-start ">
                    <span className="starers me-2">10:00</span>
                    <span className="starers ">11:59</span>
                  </div>

                  <p className="heading text-start">
                    Choosing A Quality Cookware Set
                  </p>
                  <div className="text-start">
                    <img
                      src={carts6}
                      width="26px"
                      height="26px"
                      className="me-2"
                    ></img>
                    <img src={carts7} width="26px" height="26px"></img>
                  </div>
                </div>
              </td>
              <td rowSpan={3}>
                <div
                  className="d-flex flex-column justify-content-around cart  align-items-start  p-2   "
                  style={{
                    border: "2px solid     #FFCB33",
                    backgroundColor: "rgba(255,102,51,0.05)",
                    width:"150px"
                  }}
                >
                  <div className="d-flex flex-column">
                    <div className="d-flex gap-1">
                      <span className="staryellow ">10:00</span>
                      <span className="staryellow">12:59</span>
                    </div>
                    <p className="heading text-start">
                      Astronomy Binoculars A Great Alternative
                    </p>
                  </div>

                  <div className="text-start">
                    <img
                      src={card5}
                      width="26px"
                      height="26px"
                      className="me-2"
                    ></img>
                    <img src={card6} width="26px" height="26px"></img>
                  </div>
                </div>
              </td>
              <td></td>
              <td></td>
            </tr>

            <tr>
              <td
                style={{
                  height: "67px",
                  width: "62px",
                  textAlign: "center",
                  verticalAlign: "middle",
                }}
              >
                11
              </td>
              <td></td>

              <td rowSpan="1">
                <div
                  className="d-flex flex-column justify-content-around cart align-items-start  p-2"
                  style={{
                    border: "2px solid orange",
                    backgroundColor: "rgba(255,102,51,0.05)",
                    width:"150px"
                  }}
                >
                  <div>
                    <span className="stared">11:00</span>
                    <img
                      src={card3}
                      width="26px"
                      height="26px"
                      className="me-2"
                      alt="card7"
                    />
                    <img src={card4} width="26px" height="26px" alt="card8" />
                    <p className="cart2 " style={{ fontSize: "12px" }}>
                      The Amazing Hubble
                    </p>
                  </div>
                </div>
              </td>

              <td></td>
              <td></td>
              <td></td>
            </tr>

            <tr>
              <td
                style={{
                  height: "67px",
                  width: "62px",
                  textAlign: "center",
                  verticalAlign: "middle",
                }}
              >
                12
              </td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <div 
                className="d-flex flex-column justify-content-around cart align-items-start  p-2"
                style={{
                  border: "2px solid #8833FF",
                  backgroundColor: "#8833FF0D",
                }}
              >
                <div className="d-flex gap-1">
                  <span className="starviolet ">09:00</span>
                  <span className="starviolet">10:59</span>
                </div>
              

                <img
                  src={card9}
                  width="26px"
                  height="26px"
                  className="me-2"
                ></img>
                <img src={cards1} width="26px" height="26px"></img>
              </div>
            </tr>

            <tr>
              <td
                style={{
                  height: "67px",
                  width: "62px",
                  textAlign: "center",
                  verticalAlign: "middle",
                }}
              >
                13
              </td>
              <td></td>
              <td className="event-4" rowSpan="3">
                <div
                  className="d-flex flex-column justify-content-around cart align-items-start  p-2"
                  style={{
                    border: "2px solid #8833FF",
                    backgroundColor: "#8833FF0D",
                    width:"150px"
                  }}
                >
                  <div className="d-flex gap-1">
                    <span className="starviolet ">09:00</span>
                    <span className="starviolet">10:59</span>
                  </div>
                  <p className="cart2"> Choosing A Quality Cookware Set</p>

                  <img
                    src={card9}
                    width="26px"
                    height="26px"
                    className="me-2"
                  ></img>
                  <img src={cards1} width="26px" height="26px"></img>
                </div>
              </td>{" "}
              <td></td>
              <td rowSpan="1">
                <div
                  className="d-flex flex-column justify-content-around cart align-items-start  p-2"
                  style={{
                    border: "2px solid  #33BFFF",
                    backgroundColor: "#33BFFF0D",
                    width:"170px",
                    height:"80px"

                  }}
                >
                  <div className="row">
                    <div className="col">
                    <span className="stared">13:00</span>
                    </div>
                    <div className="col">
                  <img
                    src={card7}
                    width="26px"
                    height="26px"
                    className="me-2"
                  ></img>
                    </div>
                    <div className="col">
                    <img src={card8} width="26px" height="26px"></img>
                    </div>

                  </div>
               
                  <p className="cart2">The Amazing Hubble</p>
                </div>
              </td>
              <td></td>
              <td></td>
              <td></td>
            </tr>
            {/* Row for 2 PM */}
            <tr>
              <td
                style={{
                  height: "67px",
                  width: "62px",
                  textAlign: "center",
                  verticalAlign: "middle",
                }}
              >
                14
              </td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>

             
              <td></td>
            </tr>

            <tr>
              <td
                style={{
                  height: "67px",
                  width: "62px",
                  textAlign: "center",
                  verticalAlign: "middle",
                }}
              >
                15
              </td>
              <td></td>
              <td className="event-4" rowSpan="3">
                <div
                  className="d-flex flex-column justify-content-around cart align-items-start  p-2"
                  style={{
                    border: "2px solid #E62E7B",
                    backgroundColor: "#8833FF0D",
                    width:"150px"
                  }}
                >
                  <div className="d-flex gap-1">
                    <span className="starblue ">09:00</span>
                    <span className="starblue">10:59</span>
                  </div>

                  <p className="cart2">
                    {" "}
                    Astronomy Binoculars A Great Alternative
                  </p>

                  <img
                    src={carts2}
                    width="26px"
                    height="26px"
                    className="me-2"
                  ></img>
                  <img src={carts3} width="26px" height="26px"></img>
                </div>
              </td>{" "}
              <td></td>
              <td></td>
              <td></td>
              <td></td>
            </tr>

            <tr>
              <td
                style={{
                  height: "67px",
                  width: "62px",
                  textAlign: "center",
                  verticalAlign: "middle",
                }}
              >
                16
              </td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td className="event" rowSpan="3"></td> {/* Event spans 2-3 PM */}
              <td></td>
            </tr>

            <tr>
              <td style={{ height: "67px", width: "62px" }}>17</td>
              <td className="event-4" rowSpan="3">
                <div
                  className="d-flex flex-column justify-content-around cart align-items-start  p-2"
                  style={{
                    border: "2px solid #33BFFF",
                    backgroundColor: "#33BFFF0D",
                    width:"150px"
                  
                  }}
                >
                  <div className="d-flex gap-1">
                    <span className="starpink ">17.00</span>
                    <span className="starpink">19:59</span>
                  </div>
                  <p className="cart2">The Amazing Hubble</p>
                  <div className="row">
                    <div className="col">
                    <img
                    src={carts8}
                    width="26px"
                    height="26px"
                    className="me-2"
                  ></img>

                    </div>
                    <div className="col">
                           <img src={carts9} width="26px" height="26px"></img>
                    </div>
                    
                  </div>
                 
              
                </div>
              </td>{" "}
              <td></td>
              <td></td>
              <td></td>
              <td></td>
            </tr>

            <tr>
              <td
                style={{
                  height: "67px",
                  width: "62px",
                  textAlign: "center",
                  verticalAlign: "middle",
                }}
              >
                18
              </td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td className="event" rowSpan="2"></td> {/* Event spans 2-3 PM */}
            </tr>

            <tr>
              <td
                style={{
                  height: "67px",
                  width: "62px",
                  textAlign: "center",
                  verticalAlign: "middle",
                }}
              >
                19
              </td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td className="event" rowSpan="2"></td> {/* Event spans 2-3 PM */}
            </tr>

            <tr>
              <td
                style={{
                  height: "67px",
                  width: "62px",
                  textAlign: "center",
                  verticalAlign: "middle",
                }}
              >
                20
              </td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td className="event" rowSpan="2"></td>
              <td></td>
            </tr>
          </tbody>
        </table>





      </div>
    </div>
  );
};

export default Calendar;
