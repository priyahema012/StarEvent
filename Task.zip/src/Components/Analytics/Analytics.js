import React, { useEffect, useRef } from "react";
import ApexCharts from "apexcharts";
import line1 from "../../Assests/Images/Group 5 (1).png";
import line2 from "../../Assests/Images/Group 5 (2).png";
import line3 from "../../Assests/Images/Group 5 (3).png";
import line4 from "../../Assests/Images/Group 5 (4).png";
import chartImg from "../../Assests/Images/Group 1000002742.png";
import chart2 from "../../Assests/Images/Frame 1000007309.png";
import Classes from "./Analytics.module.css";
import elipse from "../../Assests/Images/Ellipse 761.png";
import elipse1 from "../../Assests/Images/Ellipse 762.png";
import elipse2 from "../../Assests/Images/Ellipse 764.png";
import graph from "../../Assests/Images/Frame 1000007312.png";
import arrowup from "../../Assests/Images/arrow-up.png";
import piechart from "../../Assests/Images/pie chart (2).png";
import frame from "../../Assests/Images/Frame 1000007309 (1).png";
import elipses from "../../Assests/Images/Ellipse 8.png";
import elipses1 from "../../Assests/Images/Ellipse 8 (1).png";
import elipses2 from "../../Assests/Images/Ellipse 8 (2).png";
import elipses3 from "../../Assests/Images/Ellipse 8 (3).png";

function Analytics() {
  const chartRef1 = useRef(null);
  const chartRef2 = useRef(null);

  useEffect(() => {
    if (chartRef1.current) {
      const options1 = {
        series: [44, 55, 13, 43, 22],
        chart: {
          width: 380,
          type: "pie",
        },
        labels: ["Music", "Food Fest", "Startup meet", "AI Expo", "Team E"],
        responsive: [
          {
            breakpoint: 480,
            options: {
              chart: {
                width: 200,
              },
              legend: {
                position: "bottom",
              },
            },
          },
        ],
      };

      const chart1 = new ApexCharts(chartRef1.current, options1);
      chart1.render();

      return () => {
        chart1.destroy();
      };
    }

    if (chartRef2.current) {
      const options2 = {
        series: [23, 33, 45, 32, 12],
        chart: {
          width: 120,
          type: "pie",
        },
        labels: ["Event A", "Event B", "Event C", "Event D", "Event E"],
        responsive: [
          {
            breakpoint: 480,
            options: {
              chart: {
                width: 120,
              },
              legend: {
                position: "bottom",
              },
            },
          },
        ],
      };

      const chart2 = new ApexCharts(chartRef2.current, options2);
      chart2.render();

      return () => {
        chart2.destroy();
      };
    }
  }, []);

  return (
    <div>
      <h3 className="mt-4 m-3 analytics-heading">Analytics</h3>

      <div className="row m-3 mt-4 gap-3" style={{ display: "flex" }}>
        <div
          className="col-lg-6 d-flex flex-column justify-content-between p-4 rounded rounded-2"
          style={{ backgroundColor: "#ffffff", height: "300px" }}
        >
          <div className="d-flex justify-content-between">
            <div className={Classes.sale}>Sales Comparison</div>
            <div className="dropdown">
              <button
                className="btn btn-secondary dropdown-toggle"
                type="button"
                data-bs-toggle="dropdown"
                aria-expanded="false"
                style={{ backgroundColor: "gainsboro", color: "black" }}
              >
                Weekly
              </button>
              <ul className="dropdown-menu">
                <li>
                  <a className="dropdown-item" href="#">
                    Action
                  </a>
                </li>
                <li>
                  <a className="dropdown-item" href="#">
                    Another action
                  </a>
                </li>
                <li>
                  <a className="dropdown-item" href="#">
                    Something else here
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="d-flex justify-content-center align-items-end">
            <img
              src={chartImg}
              height="230px"
              width="510px"
              alt="Sales chart"
            />
          </div>
        </div>

        <div
          className="col-lg-6 d-flex flex-column justify-content-between p-4 rounded rounded-2"
          style={{ backgroundColor: "#ffffff", height: "320px" }}
        >
          <div className="d-flex justify-content-between">
            <div className={Classes.sale}>Best Selling</div>
            <div className="dropdown">
              <button
                className="btn btn-secondary dropdown-toggle"
                type="button"
                data-bs-toggle="dropdown"
                aria-expanded="false"
                style={{ backgroundColor: "gainsboro", color: "black" }}
              >
                Weekly
              </button>
              <ul className="dropdown-menu">
                <li>
                  <a className="dropdown-item" href="#">
                    Action
                  </a>
                </li>
                <li>
                  <a className="dropdown-item" href="#">
                    Another action
                  </a>
                </li>
                <li>
                  <a className="dropdown-item" href="#">
                    Something else here
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div
            className="mt-2"
            style={{
              height: "180px",
            }}
          >
            <div className="row">
              <div className="col">
                <img src={piechart}></img>

                <div className="row">
                  <div className="col">
                    <img src={elipses}></img>
                    Music
                  </div>
                  <div className="col">
                    <img src={elipses1}></img>
                    Foodfest
                  </div>
                  <div className="col">
                    <img src={elipses2}></img>
                    Startup Meet
                  </div>
                  <div className="col">
                    <img src={elipses3}></img>
                    AI Expo
                  </div>
                </div>
              </div>
              <div className="col">
                <img src={frame}></img>
              </div>
            </div>
          </div>
        </div>

        <div className="row mt-4">
          <div className="col-lg-6 col-md-12">
            <div
              className="col-lg-12 d-flex flex-column justify-content-between p-4 rounded rounded-2"
              style={{ backgroundColor: "#ffffff", height: "auto" }}
            >
              <div className="d-flex justify-content-between">
                <div className="fs-4 fw-bold">Ticket Sold</div>
              </div>
              <table className="table table-hover">
                <thead>
                  <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Popularity</th>
                    <th scope="col">Sales</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Start Music</td>
                    <td>
                      <img src={line1} alt="line chart 1" />
                    </td>
                    <td>1000</td>
                    <td>
                      <button type="button" className="btn btn-outline-info">
                        45%
                      </button>
                    </td>
                  </tr>
                  <tr>
                    <td>Bizcon</td>
                    <td>
                      <img src={line2} alt="line chart 2" />
                    </td>
                    <td>1500</td>
                    <td>
                      <button type="button" className="btn btn-outline-success">
                        29%
                      </button>
                    </td>
                  </tr>
                  <tr>
                    <td>Startup Meet</td>
                    <td>
                      <img src={line3} alt="line chart 3" />
                    </td>
                    <td>800</td>
                    <td>
                      <button
                        type="button"
                        className="btn btn-outline-secondary"
                      >
                        18%
                      </button>
                    </td>
                  </tr>
                  <tr>
                    <td>Green Submit</td>
                    <td>
                      <img src={line4} alt="line chart 4" />
                    </td>
                    <td>1200</td>
                    <td>
                      <button type="button" className="btn btn-outline-warning">
                        25%
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div className="col-lg-6 col-md-12">
            <div className="col-lg-12 bg-white p-3">
              <table className="table border-0" style={{ width: "100%" }}>
                <thead className="p-3 border-0">
                  <tr className="text-start border-0">
                    <th>Trending Event</th>
                    <th className="dropdown border-0"></th>
                  </tr>
                </thead>
                <tbody style={{ fontSize: "12px", width: "100%" }}>
                  <tr>
                    <td className="border-0">01</td>
                    <td className="border-0">
                      Startup Founders Networking Event
                    </td>
                    <td className="border-0">
                      <div className="sales-column text-center">
                        <p>426</p>
                        <p>Sales</p>
                      </div>
                    </td>
                    <td className="border-0">
                      <img
                        src={graph}
                        alt="Graph"
                        style={{ maxWidth: "100%" }}
                      />
                    </td>
                    <td className="border-0">
                      <div className="d-flex justify-content-between">
                        <img src={arrowup} alt="Arrow up" />
                        <p className="fw-bold">5%</p>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td className="border-0">02</td>
                    <td className="border-0">Start Music</td>
                    <td className="border-0">
                      <div className="sales-column text-center">
                        <p>760</p>
                        <p>Sales</p>
                      </div>
                    </td>
                    <td className="border-0">
                      <img
                        src={graph}
                        alt="Graph"
                        style={{ maxWidth: "100%" }}
                      />
                    </td>
                    <td className="border-0">
                      <div className="d-flex justify-content-between">
                        <img src={arrowup} alt="Arrow up" />
                        <p className="fw-bold">10%</p>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td className="border-0">03</td>
                    <td className="border-0">Food Fest</td>
                    <td className="border-0">
                      <div className="sales-column text-center">
                        <p>880</p>
                        <p>Sales</p>
                      </div>
                    </td>
                    <td className="border-0">
                      <img
                        src={graph}
                        alt="Graph"
                        style={{ maxWidth: "100%" }}
                      />
                    </td>
                    <td className="border-0">
                      <div className="d-flex justify-content-between">
                        <img src={arrowup} alt="Arrow up" />
                        <p className="fw-bold">15%</p>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td className="border-0">04</td>
                    <td className="border-0">AI Expo</td>
                    <td className="border-0">
                      <div className="sales-column text-center">
                        <p>260</p>
                        <p>Sales</p>
                      </div>
                    </td>
                    <td className="border-0">
                      <img
                        src={graph}
                        alt="Graph"
                        style={{ maxWidth: "100%" }}
                      />
                    </td>
                    <td className="border-0">
                      <div className="d-flex justify-content-between">
                        <img src={arrowup} alt="Arrow up" />
                        <p className="fw-bold">12%</p>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td className="border-0">05</td>
                    <td className="border-0">Web Development Workshop</td>
                    <td className="border-0">
                      <div className="sales-column text-center">
                        <p>980</p>
                        <p>Sales</p>
                      </div>
                    </td>
                    <td className="border-0">
                      <img
                        src={graph}
                        alt="Graph"
                        style={{ maxWidth: "100%" }}
                      />
                    </td>
                    <td className="border-0">
                      <div className="d-flex justify-content-between">
                        <img src={arrowup} alt="Arrow up" />
                        <p className="fw-bold">20%</p>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Analytics;
