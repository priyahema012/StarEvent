// App.js
import React from "react";
import {
  BrowserRouter,
  Route,
  Router,
  RouterProvider,
  Routes,
} from "react-router-dom";

import Dashboard from "./Components/Dashboard/Dashboard";

import "bootstrap-icons/font/bootstrap-icons.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "antd/dist/reset.css";
import Events from "./Components/Events/Events"; // Ensure this path is correct
import Analytics from "./Components/Analytics/Analytics"; // Ensure this path is correct
import Reviews from "./Components/Reviews/Reviews"; // Ensure this path is correct
import Settings from "./Components/Settings/Settings"; // Ensure this path is correct
import "./App.css";
import Customer from "./Components/Customer/Customer";
import  Calendar  from "./Components/Calendar/Calendar";
import { createBrowserRouter } from "react-router-dom";

import Navbar from "./Components/Navbar/Navbar";

const App = () => {
  const router = createBrowserRouter([
    {
      path: "/",
      element: <Navbar />,

      children: [
        {
          path: "dash",
          element: <Dashboard />,
        },
        {
          path: "cal",
          element: <Calendar />,
        },
        {
          path: "events",
          element: <Events />,
        },
        {
          path: "customer",
          element: <Customer />, // Ensure this is under HomePrivateRouter
        },
        {
          path: "analytics",
          element: <Analytics />, // Ensure this is under HomePrivateRouter
        },
        {
          path: "reviews",
          element: <Reviews />, // Ensure this is under HomePrivateRouter
        },
        {
          path: "settings",
          element: <Settings />, // Ensure this is under HomePrivateRouter
        },
        // {
        //   path: "topnavbar",
        //   element: <TopNavbar />, // Ensure this is under HomePrivateRouter
        // },
        // {
        //   path: "sidebar",
        //   element: <Sidebar />, // Ensure this is under HomePrivateRouter
        // },
        // {
        //   path: "navpage",
        //   element: <Navpage />, // Ensure this is under HomePrivateRouter
        // },
      ],
    },
  ]);

  return (
    // <BrowserRouter>
    // <TopNavbar />
    // <Sidebar />
    //  <Routes>
    //   <Route path="/" element= { <Dashboard/>} />
    //   <Route path = "/dash" element = {<Dashboard/>} />
    //   <Route path = "/calendar" element = {<Calendar/>} />
    //   <Route path = "/events" element = {<Events/>} />
    //   <Route path = "/customer" element = {<Customer/>} />
    //   <Route path = "/analytics" element = {<Analytics/>} />
    //   <Route path = "/reviews" element = {<Reviews/>} />
    //   <Route path = "/settings" element = {<Settings/>} />
    //   <Route path = "/topnavbar" element = {<TopNavbar/>} />
    //   <Route path = "/sidebar" element = {<Sidebar/>} />

    //  </Routes>
    // </BrowserRouter>

    <div className="App ">
     
      <RouterProvider router={router} />
    
    </div>

  
  );
};

export default App;

