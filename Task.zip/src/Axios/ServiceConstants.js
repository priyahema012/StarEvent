export const BASE_URL = "https://mpclient.themaestro.in";
